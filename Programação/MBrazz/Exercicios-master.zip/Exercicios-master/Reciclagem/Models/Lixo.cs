namespace Reciclagem.Models
{
    public class Lixo
    {
        
    }
}