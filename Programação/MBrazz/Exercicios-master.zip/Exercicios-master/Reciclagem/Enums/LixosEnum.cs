namespace Reciclagem.Enums
{
    public enum LixosEnum
    {
        GARRAFA,
        PAPELAO,
        POTE_MANTEIGA,
        GUARDA_CHUVA,
        GARRAFA_PET,
        LATINHA
    }
}