namespace Reciclagem
{
    public enum TipoMensagemEnum
    {
        VERDE,
        AMARELO,
        AZUL,
        VERMELHO,
        LARANJA,
        CINZA
    }
}