namespace Reciclagem.Interfaces
{
    public interface IPapel
    {
         string ReciclarFeitoPapel();
    }
}