namespace Reciclagem.Interfaces
{
    public interface IIndefinido
    {
        string ProcurarOQueFazer();
    }
}