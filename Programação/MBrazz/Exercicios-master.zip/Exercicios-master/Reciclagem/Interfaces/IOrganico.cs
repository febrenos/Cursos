namespace Reciclagem.Interfaces
{
    public interface IOrganico
    {
         string JogarNaComposteira();
    }
}