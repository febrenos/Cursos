namespace Reciclagem.Interfaces
{
    public interface IMetal
    {
        string ReciclarFeitoMetal();
    }
}