namespace Reciclagem.Interfaces
{
    public interface IPlastico
    {
         string ReciclarFeitoPlastico();
    }
}