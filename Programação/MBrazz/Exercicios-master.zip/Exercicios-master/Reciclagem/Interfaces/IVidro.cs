namespace Reciclagem.Interfaces
{
    public interface IVidro
    {
         string ReciclarFeitoVidro();
    }
}