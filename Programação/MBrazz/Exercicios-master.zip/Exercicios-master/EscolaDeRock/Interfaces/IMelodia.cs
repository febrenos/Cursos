namespace EscolaDeRock.Interfaces
{
    public interface IMelodia
    {
         bool TocarSolo();
    }
}