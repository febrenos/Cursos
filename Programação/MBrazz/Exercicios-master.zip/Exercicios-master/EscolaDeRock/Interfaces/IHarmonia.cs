namespace EscolaDeRock.Interfaces
{  
      public interface IHarmonia
    {
        bool TocarAcordes ();   
    }
}