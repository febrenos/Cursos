namespace EscolaDeRock.Interfaces
{
    public interface IPercussao
    {
         bool ManterRitmo();
    }
}