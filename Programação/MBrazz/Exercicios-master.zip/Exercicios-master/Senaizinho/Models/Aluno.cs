using System;

namespace Senaizinho.Models {
    public class Aluno {
        public string Nome {get;set;}
        public DateTime DataNascimento;
        public string Curso {get;set;}
        public int numeroSala {get;set;}

        

    }
}