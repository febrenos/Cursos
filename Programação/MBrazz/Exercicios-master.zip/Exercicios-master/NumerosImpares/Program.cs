using System;

namespace NumerosImpares
{
    class Program
    {
        static void Main(string[] args)
        {    

            for (int i = 1; i < 100; i += 2 ){
                Console.Write(i + " ");
            }

        }
    }
}